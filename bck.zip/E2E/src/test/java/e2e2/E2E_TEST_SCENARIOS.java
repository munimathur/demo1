package e2e2;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.HashMap;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.ParaMethod;
import utility.PropertyFile;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import common.BaseFunctions;
import common.RestAssureFunctions;

import e2e_framework.ExtentTestManager;
import e2e_functions.E2E_Functions;

public class E2E_TEST_SCENARIOS extends BaseFunctions  
{

	ExtentTest report;
	protected String getcontractCOde;
	protected String FinalapplicationCode;
	protected String offerCode1;
	RequestSpecification upload;
	protected String authenticateduserid;
	
	// API 1 GET SPECIAL OFFER
	@Test(enabled = true, priority = 1, description = "special offer API", dataProvider = "Testcase1", dataProviderClass = ParaMethod.class)
	public void special_Offer(String getsubURL) 
	{
		System.out.println("MUNI ");
		BaseFunctions bs=new BaseFunctions();
		bs.get_Functions();
		if (getsubURL.contains("KONG"))
		{ 
			bs.requestURL(getsubURL);
			bs.specialOffer();
		}
		else
		{
			 System.out.println("URL is wrong");
		}
	}
	
	// API 2 GET MARKETING OFFER
	@Test(enabled = true, priority=2,description = "Marketing offer API",dataProvider = "Testcase2", dataProviderClass = ParaMethod.class)
	 public void marketing_Offer(String getsubURL) 
	 {
	BaseFunctions bs=new BaseFunctions();
		bs.get_Functions();
		if (getsubURL.contains("KONG"))
		{ 
			bs.requestURL(getsubURL);
			bs.marketingOffer();
		}
		else
		{
			 System.out.println("URL is wrong");
		}
}
	 
	// API 3 POST OFFER CALCULATION
	  
	  @Test(enabled =true, priority=3,description ="Marketing offers Calculation", dataProvider ="Testcase3", dataProviderClass = ParaMethod.class)
	  public void marketing_OfferscalCulation(String getsubURL) 
	  {
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.marketingOfferscalCulation();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	}
	  
	  
	  // 4TH POST API New Contract
	  @Test(enabled = true, priority=4,description = "Create New API",dataProvider = "Testcase4", dataProviderClass = ParaMethod.class) public
	  void create_NewContract(String getsubURL) 
	  {
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				getcontractCOde=bs.createContract();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  }
	  
	  
	  // 5th POST API Offer Proposal
	  
	  @Test(enabled = true, priority=5,description = "Offer Proposal API",dataProvider = "Testcase5", dataProviderClass = ParaMethod.class)
	  public void offer_Proposal(String getsubURL)
	  {
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.offerProposal();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  }
	   
	  // 6 th Api PATCH Offer INSERT INTO APPLICATION
	  
	  @Test(enabled = true, priority=6,description = "Offer Insert API", dataProvider = "Testcase6", dataProviderClass = ParaMethod.class)
	  public void offer_InsertIntoApplication(String getbasesubURL) {
		  
		  System.out.println(getbasesubURL+"-----------------URL MUNI Mathur---------------"+getcontractCOde);
		    String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		    System.out.println(getsubURL+"-----------------URL MUNI---------------"+getcontractCOde);
		    BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.offerInsert();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  }
	 
	  // 7th Api Post Address 1 
	 
	 @Test(enabled =true, priority=7,description = "Address Contact API", dataProvider = "Testcase7",dataProviderClass = ParaMethod.class)
	 public void address_Contact(String getbasesubURL) {
	 
		 String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.address();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  }
		 
	   
	  // 8 th Api Post Address 2
	 
		 @Test(enabled =true, priority=8,description = "Address Permanent API", dataProvider = "Testcase8", dataProviderClass = ParaMethod.class)
		 public void address_Permanent(String getbasesubURL) {
		 
			 String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
			 BaseFunctions bs=new BaseFunctions();
				bs.get_Functions();
				
			 if (getsubURL.contains("KONG"))
				{ 
					bs.requestURL(getsubURL);
					bs.address2();
				}
				else
				{
					 System.out.println("URL is wrong");
				}
		  }  
		  
		
	  // 9 th Api Post ClientDocument Driver
	  
	  @Test(enabled =true, priority=9,description = "Passport API",dataProvider = "Testcase9", dataProviderClass = ParaMethod.class) public
	  void passport_Document(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.licence();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  		
	  }  
	 
  // 10 th Api Post ClientDocument Pan Card
	  
	  @Test(enabled =true, priority=10,description = "Pan Card API",dataProvider = "Testcase10", dataProviderClass = ParaMethod.class) public
	  void pancard_Document(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.panCard();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  		
	  }  
	    
	  // 11 th Api Post ClientDocumentUpload
	  
	  @Test(enabled =true, priority=11,description ="Post Client Document Upload Insert into Application about E2E API", dataProvider = "Testcase11", dataProviderClass = ParaMethod.class) public
	 void client_DocumentUpload(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURLUpload(getsubURL);
				bs.imageUpload("./Excel/relax.jpg");
			}
			else
			{
				 System.out.println("URL is wrong");
			} 		
	  }  
	 
	  
	  // 12 th Api Put Personal Data
	  
	  @Test(enabled =true, priority=12,description ="Personal Data API", dataProvider = "Testcase12", dataProviderClass = ParaMethod.class)
	  public void personal_Data(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.personalData();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  		
	  }  
	
	  // 13 th Api Put Loan Data
	  
	  @Test(enabled =true, priority=13,description ="Put Personal Data Insert into Application about E2E API", dataProvider = "Testcase13", dataProviderClass = ParaMethod.class)
	  public void loan_Data(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		 	  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.loan();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  		
	  }  	  	  
	  // 14 th Api Post Insurance ----> Not Using as of now
	  
	  @Test(enabled =false, priority=12,description ="Post Insurance Data Insert into Application about E2E API", dataProvider = "Testcase12", dataProviderClass = ParaMethod.class) 
	  public void insurance_Data(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
	  
	  // PAGE INSTANTIATIONS 
		  report = ExtentTestManager.createTest("E2E API - TestCase 12- Put Loan Data Insert Into Application"); 
		  RestAssureFunctions oRAF = new RestAssureFunctions(report);
	  HashMap<String, String> strHeader;
	  Response response;
	  JSONObject reqBody = new JSONObject(); 
	  RequestSpecification httpRequest;
	  E2E_Functions	  objE2E = new E2E_Functions(); 
	  PropertyFile prop = new PropertyFile();
	  
	  // PAGE METHODS 
	  try { 
		  // Pre Token Calls
	  
	  String getCUIDCode = objE2E.apiCUID(report); 
	  String getToken =	  objE2E.apiToken(report, getCUIDCode);
	  
	  	  
	  // REQUEST URL 
	 if (getsubURL.contains("KONG")) 
	 { httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("=")[1]);
	  } else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") +getsubURL.split("=")[1]); }
	  
	  // HEADER 
	 strHeader = new HashMap<String, String>();
	  strHeader.put("Content-Type", "application/json");
	  strHeader.put("Authorization", "Bearer " + getToken); 
	  httpRequest = oRAF.requestHeader(httpRequest, strHeader);
	  
	  //Body
	  
	  reqBody.put("nomineeName","subham kumar");
	  reqBody.put("nomineeRelationShip", "BROTHER");
	  reqBody.put("nomineePhone", "9000111222"); 
	  reqBody.put("serviceCode", "LIFEINS");
	  
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("------------Code------------ " +response.statusCode());
	
	Assert.assertEquals(response.statusCode(), 201);
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);}
	  
	   catch (Exception | AssertionError err) {
	  System.out.println("Failed in API Call"); 
	  report.log(Status.FAIL,"E2E API - TestCase 12- Post Insurance Data Insert into Application");
	  //Assert.fail();
	    }	  
	  }
	  
	  // 15 th Api Put Employment Data
	  
	  @Test(enabled =true, priority=15,description ="Put Employement Data Insert into Application about E2E API",dataProvider = "Testcase15", dataProviderClass = ParaMethod.class)
	  public  void employement_Data(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.employment();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  		
	  }  
		 	  
	 // 16 th Api Put Bank Account
	 
	 @Test(enabled =true, priority=16,description ="Put Bank Account Insert into Application about E2E API", dataProvider ="Testcase16", dataProviderClass = ParaMethod.class) 
	 public void bank_Account(String getbasesubURL) {
		 
		 String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		
		 BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.bank();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	  		
	  } 
	  // 17 th Api Post Relatives friend
	  
	  @Test(enabled =true, priority=17,description ="Relatives Friend API", dataProvider = "Testcase17", dataProviderClass = ParaMethod.class) 
	  public void relatives_Friend(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.relative();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	   }
	  
	  	  
	// 18 th Api Post Relatives Cousin
	  
		  @Test(enabled =true, priority=18,description ="Relatives Cousin API", dataProvider = "Testcase18", dataProviderClass = ParaMethod.class) 
		  public void cousin_Data(String getbasesubURL) {
			  
			  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
			  BaseFunctions bs=new BaseFunctions();
				bs.get_Functions();
				
			 if (getsubURL.contains("KONG"))
				{ 
					bs.requestURL(getsubURL);
					bs.relativeCousin();
				}
				else
				{
					 System.out.println("URL is wrong");
				}
		   }
		  
		  
	  // 19th Api Post ContactEMail
	  
	  @Test(enabled =true, priority=19,description ="Post Contact Email Data Insert into Application about E2E API",dataProvider = "Testcase19", dataProviderClass = ParaMethod.class) 
	  public void contact_Email(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.email();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	   }
	 
	 // 20 th Api Post Contact Phone No
	  
	  @Test(enabled =true, priority=20,description ="Post Contact Email Data Insert into Application about E2E API",dataProvider = "Testcase20", dataProviderClass = ParaMethod.class)
	  public void contact_PhoneNo(String getbasesubURL) {
		  
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
			
		 if (getsubURL.contains("KONG"))
			{ 
				bs.requestURL(getsubURL);
				bs.mobile();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	   }
	 		   
		  
	  // 21 th Api GET Final Check 
	  
	  	  @Test(enabled =true, priority=21,description ="Get Final Check Data Insert into Application about E2E API",dataProvider = "Testcase21", dataProviderClass = ParaMethod.class)
	  public void final_Check(String getsubURL) 
	  	  {
		  
	  		 BaseFunctions bs=new BaseFunctions();
				bs.get_Functions();
				
			 if (getsubURL.contains("KONG"))
				{ 
					bs.requestURL(getsubURL);
					bs.finalCheck();
				}
				else
				{
					 System.out.println("URL is wrong");
				}
		   }
	  
	  		  
	  // 22 th Api Post Final Request
	
	  @Test(enabled =true, priority=22,description ="Get Final Check Data Insert into Application about E2E API",dataProvider = "Testcase22", dataProviderClass = ParaMethod.class) 
	  public void final_Request(String getbasesubURL) throws Exception 
	  {
		  String getsubURL=getbasesubURL.replaceAll("2472232503", getcontractCOde);
				  
			System.out.println("++++++++++++++++++ Final API URL -------"+getsubURL);	  
		  BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();
		
		 if (getsubURL.contains("KONG"))
			{ 
			
				bs.requestURL(getsubURL);
				
				// I am adding this remove 400 Error getting parameter 'mode' is not present
				/*RestAssureFunctions rs=new RestAssureFunctions(report);
				rs.FinalRequestParam(httpRequest);
				
				System.out.println("Query Parameter is "+ httpRequest );*/
				
				bs.finalRequest();
			}
			else
			{
				 System.out.println("URL is wrong");
			}
	   }
	
	 	  
	  //23 Post Signature Request
	  
	 @Test(enabled =true, priority=23,description ="Post Signature Request into Application about E2E API") 
	  public void signature_Request() 
	 {
		/* BaseFunctions bs=new BaseFunctions();
			bs.get_Functions();*/
	  // PAGE INSTANTIATIONS 
		 report = ExtentTestManager .createTest("E2E API - TestCase 23- Post Signature Request Data Insert Into Application" ); 
		  RestAssureFunctions oRAF = new RestAssureFunctions(report);
	 
	 HashMap<String, String> strHeader; 
	  Response response; 
	  JSONObject reqBody = new JSONObject(); 
	  RequestSpecification httpRequest ;
	  
	  E2E_Functions objE2E = new E2E_Functions(); 
	//  PropertyFile prop = new PropertyFile();
	 
		  // Pre Token Calls
	  
	  String getCUIDCode = objE2E.apiCUID(report);
	  String getToken = objE2E.apiToken(report, getCUIDCode);
		  	  
	  // REQUEST URL 
	 String getsubURL="https://psinvx001.in.nonprod/contract-signature/v1/signatureRequests";
	  httpRequest =oRAF.requestURL(getsubURL);

	  // HEADER 
	  strHeader = new HashMap<String, String>();
	  strHeader.put("Content-Type", "application/json");
	  strHeader.put("Authorization", "Bearer " + getToken); 
	  strHeader.put("x-authenticated-userid", authenticateduserid); 
	  httpRequest =oRAF.requestHeader(httpRequest, strHeader);
		
	 // bs.signatureRequest();
	  //Body
	  //here i m picking final application code from final request
	  reqBody.put(getcontractCOde,FinalapplicationCode); 
	  reqBody.put("cuid","85117"); 
	  reqBody.put("contractDocuments",""); 
	  
	  reqBody.put("$.[0].documentType","GTC"); 
	  reqBody.put("$.[0].signatureType","CONFIRMATION"); 
	  reqBody.put("$.[0].contentType","STATIC"); 
	  reqBody.put("$.[0].filename","general-terms-and-conditions"); 
	  
	  reqBody.put("$.[1].documentType","APPLICATION_FORM"); 
	  reqBody.put("$.[1].signatureType","CONFIRMATION"); 
	  reqBody.put("$.[1].contentType","GENERATED"); 
	  
	  reqBody.put("$.[2].documentType","SANCTIONAL_LETTER"); 
	  reqBody.put("$.[2].signatureType","CONFIRMATION"); 
	  reqBody.put("$.[2].contentType","GENERATED"); 
	  
	  reqBody.put("clientDocuments","null"); 
	  reqBody.put("verifications","null"); 
	  
	  System.out.println("--------------------"+httpRequest.toString());
	  
	  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
	  	    	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println("Muni");
	  System.out.println(response.asString()); 
	
	  System.out.println("------------Code----- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	}
		  
	   //24 Post Document Signature-->   APPLICATION_FORM 
	  @Test(enabled =true, priority=24,description ="POST Document Signature APPLICATION_FORM Insert into Application",dataProvider = "Testcase24", dataProviderClass = ParaMethod.class) 
	  public void application_Signature(String getbasesubURL) throws Exception{
		  
		    //here i m replacing old with new final application code
		  String getsubURL=getbasesubURL.replaceAll("3900007596", FinalapplicationCode);
		  
		  System.out.println("---------------URL "+getbasesubURL);
	  
		  // PAGE INSTANTIATIONS 
		  report = ExtentTestManager .createTest("E2E API - TestCase 24- Document Signature APPLICATION_FORM  Insert into Application" ); 
		  RestAssureFunctions oRAF = new RestAssureFunctions(report);
	  HashMap<String, String> strHeader; 
	  Response response; 
	  JSONObject reqBody = new JSONObject(); 
	  RequestSpecification httpRequest;
	  E2E_Functions objE2E = new E2E_Functions(); 
	  PropertyFile prop = new PropertyFile();
	 
		  // Pre Token Calls
	  
	  String getCUIDCode = objE2E.apiCUID(report);
	  String getToken = objE2E.apiToken(report, getCUIDCode);
	  	  	  
	  // REQUEST URL 
	  if (getsubURL.contains("KONG"))
	  { 
		  httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("=")[1]);
	 /* } 
	  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") + getsubURL.split("=")[1]); 
	  }
	  */
	  // HEADER 
	  strHeader = new HashMap<String, String>();
	  strHeader.put("Content-Type", "application/json");
	  strHeader.put("Authorization", "Bearer " + getToken); 
	  strHeader.put("x-authenticated-userid", authenticateduserid); 
	  httpRequest =oRAF.requestHeader(httpRequest, strHeader);
	  
	  //Body
	  
	  reqBody.put("type","APPLICATION_FORM"); 
	  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
	  	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("-----------Code-------- " +response.statusCode()); 
	 
	  Assert.assertEquals(response.statusCode(), 204, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	  Thread.sleep(3000);
	  }  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") +getsubURL.split("=")[1]); 
	  }
	 	  		
	  }  
	 
	  	  
	//25 Post Document Signature-->   GTC
	  @Test(enabled =true, priority=25,description ="POST Document Signature GTC Insert into Application",dataProvider = "Testcase25", dataProviderClass = ParaMethod.class) 
	  public void gtc_Signature(String getbasesubURL) {
		  
		  //here i m replacing old with new final application code
		  String getsubURL=getbasesubURL.replaceAll("3900007596", FinalapplicationCode);
	  
	  // PAGE INSTANTIATIONS 
		  report = ExtentTestManager .createTest("E2E API - TestCase 25- Document Signature GTC  Insert into Application" ); 
		  RestAssureFunctions oRAF = new RestAssureFunctions(report);
	  HashMap<String, String> strHeader; 
	  Response response; 
	  JSONObject reqBody = new JSONObject(); 
	  RequestSpecification httpRequest;
	  E2E_Functions objE2E = new E2E_Functions(); 
	  PropertyFile prop = new PropertyFile();
	  
	   // Pre Token Calls
	  
	  String getCUIDCode = objE2E.apiCUID(report);
	  String getToken = objE2E.apiToken(report, getCUIDCode);
	  	  	  
	  // REQUEST URL 
	  if (getsubURL.contains("KONG"))
	  { 
		  httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("=")[1]);
	 /* } 
	  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") + getsubURL.split("=")[1]); 
	  }*/
	  
	  // HEADER 
	  strHeader = new HashMap<String, String>();
	  strHeader.put("Content-Type", "application/json");
	  strHeader.put("Authorization", "Bearer " + getToken); 
	  httpRequest =oRAF.requestHeader(httpRequest, strHeader);
	  
	  //Body
	  
	  reqBody.put("type","GTC"); 
	  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
	  	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("-----------Code-------- " +response.statusCode()); 
	 
	  Assert.assertEquals(response.statusCode(), 204);
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	
	  }  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") +getsubURL.split("=")[1]); 
	  }
	 	  		
	  }  
	 
	  
	//26 Post Document Signature-->   SANCTIONAL_LETTER
	 //here i m replacing old with new final application code
	    @Test(enabled =true, priority=26,description ="POST Document Signature SANCTIONAL_LETTER Insert into Application",dataProvider = "Testcase26", dataProviderClass = ParaMethod.class) 
	  public void sanction_Signature(String getbasesubURL) throws Exception {
		  
		  String getsubURL=getbasesubURL.replaceAll("3900007596", FinalapplicationCode);
	  
	  // PAGE INSTANTIATIONS 
		  report = ExtentTestManager .createTest("E2E API - TestCase 26- Document Signature SANCTIONAL_LETTER Insert into Application" ); 
		  RestAssureFunctions oRAF = new RestAssureFunctions(report);
	  HashMap<String, String> strHeader; 
	  Response response; 
	  JSONObject reqBody = new JSONObject(); 
	  RequestSpecification httpRequest;
	  E2E_Functions objE2E = new E2E_Functions(); 
	  PropertyFile prop = new PropertyFile();
	  
	  // Pre Token Calls
	  
	  String getCUIDCode = objE2E.apiCUID(report);
	  String getToken = objE2E.apiToken(report, getCUIDCode);
	  	  	  
	  // REQUEST URL 
	  if (getsubURL.contains("KONG"))
	  { 
		  httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("=")[1]);
	 /* } 
	  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") + getsubURL.split("=")[1]); 
	  }
	  */
	  // HEADER 
	  strHeader = new HashMap<String, String>();
	  strHeader.put("Content-Type", "application/json");
	  strHeader.put("Authorization", "Bearer " + getToken); 
	  strHeader.put("x-authenticated-userid", authenticateduserid); 
	  httpRequest =oRAF.requestHeader(httpRequest, strHeader);
	  
	  //Body
	  
	  reqBody.put("type","SANCTIONAL_LETTER"); 
	  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
	  	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("-----------Code-------- " +response.statusCode()); 
	 
	  Assert.assertEquals(response.statusCode(), 204, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("--------------Response Body is =>  " + responseBody);
	 
	  }  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") +getsubURL.split("=")[1]); 
	  }
	 	  		
	  }  
		
	  
	  //27 Post Contract Signature Not now 
	  @Test(enabled =true, priority=27,description ="POST Contract Signature Insert into E2E API Application",dataProvider = "Testcase27", dataProviderClass = ParaMethod.class) 
	  public void contract_Signature(String getbasesubURL) throws InterruptedException {
		 
		  String getsubURL=getbasesubURL.replaceAll("3900007596", FinalapplicationCode);
	  
	  // PAGE INSTANTIATIONS 
		  report = ExtentTestManager .createTest("E2E API - TestCase 27- Post Contract Signature  Insert into E2E API Application" ); 
		  RestAssureFunctions oRAF = new RestAssureFunctions(report);
	  HashMap<String, String> strHeader; 
	  Response response; 
	 // JSONObject reqBody = new JSONObject(); 
	  RequestSpecification httpRequest;
	  E2E_Functions objE2E = new E2E_Functions(); 
	  PropertyFile prop = new PropertyFile();
	 
		  // Pre Token Calls
	  
	  String getCUIDCode = objE2E.apiCUID(report);
	  String getToken = objE2E.apiToken(report, getCUIDCode);
	  
	  	  
	  // REQUEST URL 
	  if (getsubURL.contains("KONG"))
	  { 
		  httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("=")[1]); 
		  /*} 
	  else 
	  { httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") + getsubURL.split("=")[1]);  
	  }*/
	  
	  // HEADER 
	  strHeader = new HashMap<String, String>();
	  strHeader.put("Content-Type", "application/json");
	  strHeader.put("Authorization", "Bearer " + getToken);
	  strHeader.put("x-authenticated-userid", authenticateduserid); 
	  httpRequest =oRAF.requestHeader(httpRequest, strHeader);
	  
	  //Body
	  	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("-----------------------Code- " +response.statusCode()); 
	 
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");

	  String responseBody = response.getBody().asString();
	  System.out.println("--------------Response Body is =>  " + responseBody);
	   
}	 	 else 
{ 
	httpRequest = oRAF.requestURL(prop.readPropFile("atlURL") +getsubURL.split("=")[1]); 
}
	  		
}   
}
