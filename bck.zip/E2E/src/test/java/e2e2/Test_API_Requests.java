package e2e2;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.HashMap;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import utility.ParaMethod;
import utility.PropertyFile;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import common.RestAssureFunctions;
import e2e_framework.ExtentTestManager;
import e2e_framework.ParallelClassesBase;
import e2e_functions.E2E_Functions;

public class Test_API_Requests extends ParallelClassesBase{

	ExtentTest report;

	@Test(description = "Marketing offer about E2E API", dataProvider = "Testcase2", dataProviderClass = ParaMethod.class)
	public void markettingCalculation(String getsubURL) {
		/* Same as above message. */
		report = ExtentTestManager
				.createTest("E2E API - TestCase 2-Marketing Offers Calculation");
		RestAssureFunctions oRAF = new RestAssureFunctions(report);
		HashMap<String, String> strHeader;
		Response response;
		JSONObject reqBody = new JSONObject();
		RequestSpecification httpRequest;
		E2E_Functions objE2E = new E2E_Functions();
		PropertyFile prop = new PropertyFile();
		
		try {
			/*Getting tokens */
			String getCUIDCode = objE2E.apiCUID(report);
			String getToken = objE2E.apiToken(report, getCUIDCode);
			/*Getting URLs from Excel*/
			if (getsubURL.contains("KONG")) {
				httpRequest = oRAF.requestURL(prop.readPropFile("kongURL")
						+ getsubURL.split("=")[1]);
			} else {
				httpRequest = oRAF.requestURL(prop.readPropFile("atlURL")
						+ getsubURL.split("=")[1]);
			}
			/*Adding Headers*/
			strHeader = new HashMap<String, String>();
			strHeader.put("Content-Type", "application/json");
			strHeader.put("Authorization", "Bearer " + getToken);
			//strHeader.put("x-authenticated-userid", "10933372");
			
			httpRequest = oRAF.requestHeader(httpRequest, strHeader);

			/*Body*/
			reqBody.put("income", "30000");
			//reqBody.put("loanPurpose", "EU01");
			reqBody.put("salaryPaymentMethod", "CASH");
			httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());

			/*Execute API Request*/
 			response = oRAF.execute(httpRequest, "post");
			System.out.println(response.asString());
			System.out.println("Code- "+response.statusCode());
			Assert.assertEquals( response.statusCode(),202);
			
		} catch (Exception e) {
			System.out.println("Failed in API Call"+ e.getStackTrace());
			report.log(Status.FAIL,
					"E2E API - TestCase 3- MArketingoffer Calculation");
			Assert.fail();
		}

	}
}
