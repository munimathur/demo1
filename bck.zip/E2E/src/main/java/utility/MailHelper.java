package utility;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailHelper {

	public void sendMail() throws AddressException, MessagingException {
		
		 final String username="HCG/muni.mathur200441";
		 final String password="Welcome@123";
		
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "outlook.homecredit.co.in");
		//outlook.homecredit.co.in
		//443
		props.put("mail.smtp.port", "443");
		
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress("muni.mathur200441@homecredit.co.in"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("muni.mathur200441@homecredit.co.in"));
		message.setSubject("E2E Automation Report ");
		message.setText("Hi Team"+"\n" +"This is the Automation Report");
		Transport.send(message);
		System.out.println("Done");
		
	}
}
