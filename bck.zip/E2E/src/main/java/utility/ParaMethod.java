package utility;

import java.io.FileReader;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.DataProvider;

// Creating DataProvider
public class ParaMethod {
	@DataProvider(name = "Testcase1")
	public static Object[][] Testcase1() throws Exception {
	//	ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		/*ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_1");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}*/
		
		/*JSONObject getObject = new JSONObject("C:/Users/muni.mathur200441/E2E/Excel/JSON.json");
		JSONArray getArr = getObject.getJSONArray("data");
		JSONObject getChildObj = getArr.getJSONObject(0);
		if(getChildObj.getString("TestCaseID")== "TestCase_1")
		{
			JSONArray getPArray = new JSONArray();
			JSONArray getArray = new JSONArray();
			getArray.put(getChildObj.getString("GetURL1"));
			getArray.put(getChildObj.getString("GetURL2"));
			getPArray.put(getArray);
		}*/
	

		JSONParser jsonParser = new JSONParser();
		try( FileReader reader = new FileReader("C:\\Users\\saurav.kumar202162\\Desktop\\dataList.json") ){
			Object obj = jsonParser.parse(reader);

			JSONObject data = (JSONObject) obj;
			System.out.println(data);
			JSONArray dataList = (JSONArray)data.get("data");
		
		
		
		
		
		
		
				
		return tabArray;
	}

	@DataProvider(name = "Testcase2")
	public static Object[][] Testcase2() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_2");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase3")
	public static Object[][] Testcase3() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_3");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase4")
	public static Object[][] Testcase4() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_4");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase5")
	public static Object[][] Testcase5() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_5");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase6")
	public static Object[][] Testcase6() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_6");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase7")
	public static Object[][] Testcase7() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_7");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase8")
	public static Object[][] Testcase8() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_8");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase9")
	public static Object[][] Testcase9() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_9");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}

	@DataProvider(name = "Testcase10")
	public static Object[][] Testcase10() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_10");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase11")
	public static Object[][] Testcase11() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_11");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase12")
	public static Object[][] Testcase12() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_12");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	
	@DataProvider(name = "Testcase13")
	public static Object[][] Testcase13() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_13");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase14")
	public static Object[][] Testcase14() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_14");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase15")
	public static Object[][] Testcase15() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_15");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase16")
	public static Object[][] Testcase16() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_16");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase17")
	public static Object[][] Testcase17() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_17");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase18")
	public static Object[][] Testcase18() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_18");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase19")
	public static Object[][] Testcase19() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_19");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase20")
	public static Object[][] Testcase20() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_20");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase21")
	public static Object[][] Testcase21() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_21");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase22")
	public static Object[][] Testcase22() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_22");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	/*@DataProvider(name = "Testcase23")
	public static Object[][] Testcase23() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_23");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}*/
	
	@DataProvider(name = "Testcase24")
	public static Object[][] Testcase24() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_24");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase25")
	public static Object[][] Testcase25() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_25");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase26")
	public static Object[][] Testcase26() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_26");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	@DataProvider(name = "Testcase27")
	public static Object[][] Testcase27() throws Exception {
		ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		ArrayList<ArrayList<String>> getList = readExl
				.getCellData("TestCase_27");
		tabArray = new String[getList.size()][getList.get(0).size()];
		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}
	
	
}
