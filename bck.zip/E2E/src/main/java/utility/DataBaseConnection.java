package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.aventstack.extentreports.ExtentTest;

public class DataBaseConnection 
{
	
	//***********Declaration**********
	 public static ExtentTest logger;
		
	//*********Constructor*********
	 public DataBaseConnection(ExtentTest logger) 
	 {
	   this.logger = logger;
	 }	
		
	public static Connection dbConnection(String url, String Uname, String Pwd) throws Exception{
		 Class.forName("oracle.jdbc.driver.OracleDriver");
         //Reference to connection interface
		 Connection con = DriverManager.getConnection(url,Uname,Pwd);
		 System.out.println("Database Connection Successful");
		 //logger.log(Status.INFO, "Database Connection Successful : " + url);
		 return con;
	}
		
	public static ResultSet executeQuery(Connection con, String sql) throws Exception{
		 Statement st = con.createStatement();
		 System.out.println("createStatement Successful");
		 ResultSet rs = st.executeQuery(sql);
         System.out.println("Query execute Successful");
         System.out.println("SQL query : " + sql);
         //logger.log(Status.INFO, "SQL query : " + sql);
         return rs;
	}
	
	public static void executeUpdate(Connection con, String sql) throws Exception{
		 Statement st = con.createStatement();
		 System.out.println("create Statement Successful");
		 try{
		 st.executeUpdate(sql);
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		
        System.out.println("Update Query execute Successful");
        System.out.println("SQL query : " + sql);
	}
	
/*	public void verifyResultSet(ResultSet rs, String matchvalue) throws Exception{
		// rs.next();
		 int count = 0;
         //int count = rs.getInt("ID");
		 while(rs.next()) {
			    System.out.println(rs.getString(1));
			}
			rs.absolute(1);
			System.out.println(rs.getString(1));
         if (rs != null) {
        	  while (rs.next()) {
        	    count = rs.getInt(1);
        	  }
        	  count = rs.getInt(1); //this will throw Exhausted resultset
        	}
         rs.close();
         
         if(String.valueOf(count).matches(matchvalue)){
        	 System.out.println("MyTable has " + count + " row(s).");
             logger.log(Status.PASS, "MyTable has " + count + " row(s).");
         }else{
        	 System.out.println("MyTable has " + count + " row(s). --- Fail");
             logger.log(Status.FAIL, "MyTable has " + count + " row(s) which is wrong.");
         }
        
	}*/
	
	
	public static void closeConnection(Connection con) throws Exception
	{
		 con.close();
		 //logger.log(Status.INFO, "Database Connection Closed");
	}
	
	/*Delete contract Id*/
	public static void deleteContractID( ){
		//Read contract ID from DATA SOURCE
		String contract_id="85117";
		String Url= "jdbc:oracle:thin:@SDINBX001.IN.NONPROD:1521/IN99B1.HOMECREDIT.IN";
		String username="QUEST_TEST_1";
		String Password="QUEST_TEST_1";
		String Delete_Query="update application  set status='C' where created_by='"+contract_id+"'";
				
		System.out.println("Delete Query: "+Delete_Query);
		try {
			Connection con=dbConnection(Url,username,Password);
			executeUpdate(con, Delete_Query);
			con.commit();
			con.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
    public static void main(String a[]) throws Exception
    {
    	try
    	{     		
    		String Url= "jdbc:oracle:thin:@INFHS01.IN.INFRA:1521/INOAPICS.IN.INFRA";
    		String username="CS_USER";
    		String Password="CS_USER";
    		String SQLQuery="select * from CS_USER where CUID='85117'";
    				
    		Connection con=dbConnection(Url,username,Password);
    		ResultSet rs=executeQuery(con,SQLQuery); 
    		
    		int count = 0;
    		while(rs.next())
    		{
    			//System.out.println(rs.getInt(1)+"  "+rs.getString(4)+"  "+rs.getString(5));  
    			System.out.println(rs.getInt("ID"));
    			count++;
    		}
    		System.out.println(count);
    		//con.close();  
    		closeConnection(con);
    		  
    		}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}  
    		  
    }
    	    
}

