package common;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

//import utility.CryptoFunctions;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAssureFunctions 

{

	/*****************************************************************/
	/*
	 * The Purpose of this Class is to declare the Logger Globally.
	 * We are creating constructor of RestAssuredFunctions 
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
		
	//public ExtentTest logger;


	public RestAssureFunctions(ExtentTest report) 
	{
		
	}

	
	// ********* Defining Constructor*********
/*	public RestAssureFunctions(ExtentTest logger) 
	{
		this.logger = logger;
	}
	*/
	/*****************************************************************/
	/*
	 * The Purpose of this methiod  is to define the URL .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	

	public RequestSpecification requestURL(String srtURL)
	{
		RestAssured.baseURI = srtURL;
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().queryParam("page", 4);
		//logger.log(Status.PASS, "API URL : " + srtURL);
		return httpRequest;
	}
	
	/*****************************************************************/
	/*
	 * The Purpose of this methiod  is to define the Header .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/

	public RequestSpecification requestHeader(RequestSpecification httpRequest,HashMap<String, String> strHeader)
	{
		List<Header> list = new ArrayList<Header>();
		for (Map.Entry<String, String> entry : strHeader.entrySet())
		{
			String key = entry.getKey();
			String value = entry.getValue();
			Header h = new Header(key, value);
			list.add(h);
		}
		Headers header = new Headers(list);
		//logger.log(Status.INFO, "Header : " + list);
		httpRequest.headers(header);
		return httpRequest;
	}

	
	/*****************************************************************/
	/*
	 * The Purpose of this method  is to define the Request Body .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	public RequestSpecification requestBody(RequestSpecification httpRequest,String reqBody) {
		httpRequest.body(reqBody);
		//logger.log(Status.INFO, "Request Body : " + reqBody);
		return httpRequest;
	}

	
	/*****************************************************************/
	/*
	 * The Purpose of this method  is to define the Upload Images  .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	public RequestSpecification uploadImages(RequestSpecification httpRequest, String path)
	{
        File imageFile = new File(path); 
        httpRequest.given().multiPart("documentType","ADDRESS_PROOF_DOCUMENT").multiPart("content", imageFile,"image/jpeg"); 
         return httpRequest;
    }
	
	
	// This is for Final Request
	
	public RequestSpecification FinalRequestParam(RequestSpecification httpRequest)
	{		
		RequestSpecification httpFinalRequest = RestAssured.given().queryParam("mode", "FINAL_REQUEST"); 
         return httpFinalRequest;
    }	
	
	/* 
	 public final(RequestSpecification response)
	 {
		 RequestSpecification response = RestAssured.given().queryParam("mode", "FINAL_REQUEST");
	     return response;
	 }*/
	               
	
	
	
	/*****************************************************************/
	/*
	 * The Purpose of this method is to define the Rest Assured methods  .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	

	public Response execute(RequestSpecification httpRequest, String reqType) {
		Response response = null;
		switch (reqType) {
		case "get":
			System.out.println("GET Request");
			response = httpRequest.request(Method.GET);
			//logger.log(Status.PASS, "Performed : GET Request");
			break;
		case "post":
			System.out.println("POST Request");
			response = httpRequest.request(Method.POST);
			//logger.log(Status.PASS, "Performed : POST Request");
			break;
	
		case "patch":
			System.out.println("Patch Request");
			response = httpRequest.request(Method.PATCH);
			//logger.log(Status.PASS, "Performed : PATCH Request");
			break;
		case "delete":
			System.out.println("DELETE Request");
			response = httpRequest.request(Method.DELETE);
			//logger.log(Status.PASS, "Performed : DELETE Request");
			break;
		case "put":
			System.out.println("PUT Request");
			response = httpRequest.request(Method.PUT);
			//logger.log(Status.PASS, "Performed : PUT Request");
			break;
		default:
			//logger.log(Status.WARNING, "NOT FOUND");
			System.out.println("NOT FOUND");
		}
		return response;
	}
	
	/*****************************************************************/
	/*
	 * The Purpose of this method  is to stored  the Response  .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	public String getResponse(Response response)
	{
		String getResponseBody = response.getBody().asString();
		//logger.log(Status.INFO, "Get Response : " + getResponseBody);
		return getResponseBody;
	}

	
	/*****************************************************************/
	/*
	 * The Purpose of this method  is to Encrypted Responses  .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	public String getEncryptedResponse(String resBody) throws Exception
	{
		JSONObject myObject = new JSONObject(resBody);
		String getResponse = (String) myObject.get("response");
		//logger.log(Status.INFO, "Get only the encrypted response : " + getResponse);
		return getResponse;
	}

	/*****************************************************************/
	/*
	 * The Purpose of this method is to Validate the Responses  .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	

	// Validate Responses
	public void validateResponse(String responseText) {

		JSONObject myObject = new JSONObject(responseText);
		String reqBody = (String) myObject.get("transactionRemarks");

		if (reqBody.contains("Transaction success")) {
			//logger.log(Status.PASS, "Successful Transaction : " + reqBody);
		}

		if (reqBody.contains("Transaction fail")) {
			//logger.log(Status.FAIL, "Transaction Failed : " + reqBody);
		}

		System.out.println(responseText);
	}

	

}
