package common;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import utility.PropertyFile;

import com.aventstack.extentreports.ExtentTest;

import e2e_framework.ExtentTestManager;
import e2e_framework.ParallelClassesBase;
import e2e_functions.E2E_Functions;

/*****************************************************************/
/*
 * BaseFunctions Class
 * The Purpose of this Class is to define all the reusable methods.
 * @author  Muni Mathur
*/
/*****************************************************************/


public class BaseFunctions extends ParallelClassesBase
{
	static ExtentTest report;
	public String contractCOde;
	protected String getcontractCOde;
	protected String FinalapplicationCode;
	protected String offerCode1;
	RequestSpecification upload;
	protected String authenticateduserid;
	
	protected RestAssureFunctions oRAF; 
	protected Response response;
	protected HashMap<String, String> strHeader;
	protected JSONObject reqBody;
	protected RequestSpecification httpRequest;
	protected E2E_Functions objE2E;
	protected PropertyFile prop;
	protected String getCUIDCode;
	protected String getToken;
	protected RestAssureFunctions rest;
	
	
	/*****************************************************************/
	 /*
	  * Get Functions Method
	  * This bellow function contain common functions which is used for all other methods..
	  * @author  Muni Mathur
	 */
	 /*****************************************************************/ 
	public void get_Functions()
	{
		report = ExtentTestManager.createTest("E2E API Automation Scripts");
		oRAF = new RestAssureFunctions(report);		
		// Response interface , request getbody,getheader,getcookie		
		reqBody = new JSONObject();
		objE2E = new E2E_Functions();
		prop = new PropertyFile();
		
		getCUIDCode = objE2E.apiCUID(report);
		getToken = objE2E.apiToken(report, getCUIDCode);
		rest= new RestAssureFunctions(report);
	}
	
	/*****************************************************************/
	 /*
	  * Request URL Functions
	  * This bellow function contain common functions which is used for all other methods..
	  * @author  Muni Mathur
	 */
	 /*****************************************************************/ 
	
	
	public void requestURL(String getsubURL)
	{
		httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("#")[1]).queryParam("mode", "FINAL_REQUEST");
		System.out.println(httpRequest.get());
		
		System.out.println("Printing the URL :--------------"+prop.readPropFile("kongURL") + getsubURL.split("#")[1]);
		authenticateduserid = "85117";
		strHeader = new HashMap<String, String>();
		strHeader.put("Content-Type", "application/json");
		strHeader.put("Authorization", "Bearer " + getToken); 
		strHeader.put("x-authenticated-userid", authenticateduserid); 
		httpRequest =oRAF.requestHeader(httpRequest, strHeader);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
	}
	
	
	/*For Image Upload*/
	public void requestURLUpload(String getsubURL)
	{
		httpRequest =oRAF.requestURL(prop.readPropFile("kongURL") + getsubURL.split("#")[1]);
		System.out.println("URL Muni:--------------"+prop.readPropFile("kongURL") + getsubURL.split("#")[1]);
		authenticateduserid = "85117";
		strHeader = new HashMap<String, String>();
		strHeader.put("Authorization", "Bearer " + getToken); 
		strHeader.put("x-authenticated-userid", authenticateduserid); 
		httpRequest =oRAF.requestHeader(httpRequest, strHeader);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	
	/*****************************************************************/
	/*
	 * special offer API
	 * This bellow function helps to run the special offer API.
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	
		public void specialOffer()
	{
		response = oRAF.execute(httpRequest, "get");
		//To Fetch value from Body Create a object 
		JsonPath jp = new JsonPath(response.asString());
		jp.get("maxLoanAmount");
		System.out.println(" "+jp.get("maxLoanAmount.amount"));
		System.out.println("---------- Code----------- " + response.statusCode());					
		Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
		String responseBody = response.getBody().asString();
		System.out.println("Response Body is =>  " + responseBody);
	}
	
		
		/*****************************************************************/
		/*
		 * Marketing Offer API
		 * This bellow function helps to run the Marketing offer API.
		 * @author  Muni Mathur
		*/
		/*****************************************************************/
		
		
	public void marketingOffer()
	{
		
		  response = oRAF.execute(httpRequest, "get");
		  System.out.println(response.asString());
		  System.out.println("--------------Code---------- " + response.statusCode());
		  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
		  String responseBody =response.getBody().asString(); 
		  System.out.println("Response Body is =>  " + responseBody); 
	}
	
	
	/*****************************************************************/
	/*
	 * Marketing Offer Calculation API
	 * This bellow function helps to run the Marketing offer Calculation API.
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	public void marketingOfferscalCulation()
	{
		
		 reqBody.put("income", "35000");
		 reqBody.put("salaryPaymentMethod","CASH");
		 httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
		 response = oRAF.execute(httpRequest, "post");
		 System.out.println(response.asString()); 
		 System.out.println("--------------Code---------- " +response.statusCode()); 
		 Assert.assertEquals(response.statusCode(), 202, "Status code missmatch");	 
	}
	
	/*****************************************************************/
	/*
	 * Create Contract API
	 * This bellow function helps to run the Create Contract API.
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	public String createContract()
	{
		
		 response = oRAF.execute(httpRequest, "post");
		  System.out.println(response.asString()); 
		  System.out.println("--------------Code----------- " +response.statusCode());
		  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
		  String responseBody = response.getBody().asString();
		  System.out.println("Response Body is =>  " + responseBody);
		  JsonPath jp = new JsonPath(response.asString());
		  contractCOde=jp.get("$.data[0].contractNumber");
		  System.out.println(" -------------------Contract Code is ==> "+jp.get("contractCode"));
		  contractCOde=jp.get("contractCode");
		  System.out.println(" -------------------Contract Code is ==>"+contractCOde);
		  return contractCOde;
	}
	
	/*****************************************************************/
	/*
	 * Offer Proposal API
	 * This bellow function helps to run the Offer Proposal API.
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
public void offerProposal()
{
	 reqBody.put("loanAmount", "100000"); 
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("------------offerProposal Code----------- " +response.statusCode()); 
    
	  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is ---->  " + responseBody);
	  
	  // This is to get Offer Code & we are using in Patch Body 
	  /*JsonPath jp = new JsonPath(response.asString());
	 	offerCode1=jp.get("$.data[0].offerCode");
	 System.out.println(" --------------- Offer Code is ==> "+jp.get("offerCode1"));*/
	  
	    JSONObject obj = new JSONObject(responseBody);
		 JSONArray array = obj.getJSONArray("data");
	     offerCode1 = array.getJSONObject(0).getString("offerCode"); 
	     System.out.println("Muni offercode------------"+offerCode1);
		
	}

/*****************************************************************/
/*
 * Patch Offer Insert API
 * This bellow function helps to run the PAtch Offer Insert API.
 * @author  Muni Mathur
*/
/*****************************************************************/

public void offerInsert(){
	// Adding Offer Code in Body 
		  System.out.println("---------------------------------"+offerCode1);
		  reqBody.put("offerCode", offerCode1);
		  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
		  
		  // EXECUTE 
		  response = oRAF.execute(httpRequest, "patch");
		  System.out.println(response.asString()); 
		  System.out.println("------------Code--------- " +response.statusCode()); 
		 
		  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
		  String responseBody = response.getBody().asString();
		  System.out.println("--------------Response Body is =>  " + responseBody);
}

/*****************************************************************/
/*
 * Contact Address API
 * This bellow function helps to run the Address Contact API.
 * @author  Muni Mathur
*/
/*****************************************************************/

public void address()
{
	
	// Body 
		  reqBody.put("addressType", "CONTACT"); 
		  reqBody.put("building","1232"); 
		  reqBody.put("country", "IN"); 
		  reqBody.put("district", "Chandigarh"); 
		  reqBody.put("districtCode", "null"); 
		  reqBody.put("floorNumber", "1"); 
		  reqBody.put("formattedAddress", "");
		  reqBody.put("landmark", "Hotel");
		  reqBody.put("locality", "DJDEIEHFJI");
		  reqBody.put("state", "Chandigarh"); 
		  reqBody.put("stateCode", "null");
		  reqBody.put("streetName", "G.T.Road");
		  reqBody.put("town", "Chandigarh"); 
		  reqBody.put("zipCode", "160022");
		  reqBody.put("region", "160022"); 
		  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
		  
		  // EXECUTE 
		  response = oRAF.execute(httpRequest, "post");
		  System.out.println(response.asString()); 
		  System.out.println("----------------Code------------ " +response.statusCode()); 
		  
		  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
		  String responseBody = response.getBody().asString();
		  System.out.println("Response Body is =>  " + responseBody);
}


/*****************************************************************/
/*
 * Permanent Address API
 * This bellow function helps to run the Permanent Address Contact API.
 * @author  Muni Mathur
*/
/*****************************************************************/

public void address2()
{ 
	 // Body 
	  reqBody.put("addressType", "PERMANENT"); 
	  reqBody.put("building","1232"); 
	  reqBody.put("country", "IN"); 
	  reqBody.put("district", "Chandigarh"); 
	  reqBody.put("districtCode", "null"); 
	  reqBody.put("floorNumber", "1"); 
	  reqBody.put("formattedAddress", "");
	  reqBody.put("landmark", "Hotel");
	  reqBody.put("locality", "DJDEIEHFJI");
	  reqBody.put("state", "Chandigarh"); 
	  reqBody.put("stateCode", "null");
	  reqBody.put("streetName", "G.T.Road");
	  reqBody.put("town", "Chandigarh"); 
	  reqBody.put("zipCode", "160022");
	  reqBody.put("region", "160022"); 
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("----------------Code------------ " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
}

/*****************************************************************/
/*
 * Client Document Upload API
 * This bellow function helps to run the Client Document Upload API.
 * We are uploading Driving License.
 * @author  Muni Mathur
*/
/*****************************************************************/
 public void licence()
 {
	//BODY
	  
	 reqBody.put("documentType", "ADDRESS_PROOF_DOCUMENT");
	  reqBody.put("documentName", "DRIVERS_LICENCE"); 
	  httpRequest =oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("----------------Code------ " +response.statusCode());
	 
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	 String responseBody = response.getBody().asString();
	 System.out.println("Response Body is =>  " + responseBody);
	 
 }
 
 /*****************************************************************/
 /*
  * Client Document Upload API
  * This bellow function helps to run the Client Document Upload API.
  * We are uploading Pan Card.
  * @author  Muni Mathur
 */
 /*****************************************************************/
 public void panCard()
 {
	 
	 reqBody.put("documentType", "PAN_CARD");
	  reqBody.put("documentName", "PAN_CARD"); 
	  reqBody.put("documentNumber", "BFVPB4341D");
	  httpRequest =oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("----------------Code------ " +response.statusCode());
	 
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	 String responseBody = response.getBody().asString();
	 System.out.println("Response Body is =>  " + responseBody);
	 }   
 
 /*****************************************************************/
 /*
  * Image Upload API
  * This bellow function helps to run the Client Document/Image Upload API.
  * We are uploading document image in jpg format only.
  * @author  Muni Mathur
 */
 /*****************************************************************/
 
 public void imageUpload(String imagePath)
 {
	 
	  reqBody.put("documentType", "ADDRESS_PROOF_DOCUMENT"); 
	   rest.uploadImages(httpRequest, imagePath);
	  	  
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("--------------------Code- " +response.statusCode()); 
	  
	 Assert.assertEquals(response.statusCode(), 204, "Status code missmatch");
	
	 
 }
 
 /*****************************************************************/
 /*
  * Personal Data API
  * This bellow function helps to run the Personal Data API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 public void personalData()
 {
	 reqBody.put("firstName", "RR"); 
	  reqBody.put("lastName", "MM");
	  reqBody.put("middleName", "AmritEE");
	  reqBody.put("fatherFirstName","BADRI");
	  reqBody.put("fatherLastName", "MEHTA");
	  reqBody.put("fatherMiddleName", ""); 
	  reqBody.put("gender", "M");
	  reqBody.put("birthDate", "1977-07-29"); 
	  reqBody.put("motherName", "AB"); 
	  reqBody.put("preferredLanguage", "HIND");
	  
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "put");
	  System.out.println(response.asString());
	  System.out.println("------------Code------------ " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("---------------------Response Body is =>  " + responseBody);
 }
 
 /*****************************************************************/
 /*
  * Loan Data API
  * This bellow function helps to run the Loan Data API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 
 public void loan()
 {
	 reqBody.put("accompaignment","null"); 
	  reqBody.put("dependents", 1);
	  reqBody.put("education", "10th PASS"); 
	  reqBody.put("houseType", "");
	  reqBody.put("loanPurpose", "EU01"); 
	  reqBody.put("maritalStatus","SINGLE"); 
	  reqBody.put("netIncome", 30000); 
	  reqBody.put("occupation","SELFEMPLOYED"); 
	  reqBody.put("otherDebts", 1836);
	  reqBody.put("repaymentType", "DD"); 
	  reqBody.put("salaryPaymentMethod", "ACCOUNT"); 
	  reqBody.put("vpa", "null"); 
	  reqBody.put("householdIncome", "null"); 
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "put");
	  System.out.println(response.asString());
	  System.out.println("-----------Code- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
 }
 
 public void insurance()
 {
	 
 }
 
 /*****************************************************************/
 /*
  * Employment  Data API
  * This bellow function helps to run the Employment Data API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 
 public void employment()
 {
	 reqBody.put("employerName","CITY HEART HOTEL");
	  reqBody.put("department", "");
	  reqBody.put("occupation", "SELFEMPLOYED"); 
	  reqBody.put("industry", "SERVICES");
	  reqBody.put("profession", "OTHER");
	  reqBody.put("employmentType", "PERMANENT");
	   
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "put");
	  System.out.println(response.asString()); 
	  System.out.println("--------------Code---------- " +response.statusCode()); 
	 
	  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
 }
 
 /*****************************************************************/
 /*
  * Bank Data API
  * This bellow function helps to run the Bank Data API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 
 public void bank()
 {
	 reqBody.put("accountType","SAVING"); 
	  reqBody.put("bankName","BANK OF INDIA");
	  reqBody.put("bankBranchName","Sector - 35");
	  reqBody.put("bankBranchCode", "BKID0006203");
	  reqBody.put("ifsc","BKID0006203"); 
	  reqBody.put("micr", "160013002");
	  reqBody.put("holderName", "BEDEIJHF BCFEC");
	  reqBody.put("accountNumber", "743466799123968");
	  
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "put");
	  System.out.println(response.asString()); 
	  System.out.println("-----------Code----------- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
 }
 
 /*****************************************************************/
 /*
  * Relative API
  * This bellow function helps to run the Relative API.
  * We are passing relation type Friend.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 
 public void relative()
 {
	 reqBody.put("firstName","CCDED"); 
	  reqBody.put("lastName", "DGDEF");
	  reqBody.put("phone", "6785902311");
	  reqBody.put("relationType","FRIEND"); 
	  reqBody.put("phoneSource","MOBILE_CONTACTS");
	  
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("------------Code----------- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 204, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
 }
 
 
 /*****************************************************************/
 /*
  * Relative API
  * This bellow function helps to run the Relative API.
  * We are passing relation type Cousin.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 public void relativeCousin()
 {
	 reqBody.put("firstName","BADEDD"); 
	  reqBody.put("lastName", "DADEF");
	  reqBody.put("phone", "8888769090");
	  reqBody.put("relationType","CLOSE_FAMILY"); 
	  reqBody.put("phoneSource","MOBILE_CONTACTS");
	  
	  httpRequest = oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("------------Code----------- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 204, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	 
 }
 
 /*****************************************************************/
 /*
  * Contact Email API
  * This bellow function helps to run the Contact Email API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 
 public void email()
 {
	 reqBody.put("contactId",""); 
	  reqBody.put("contactType", "PRIMARY_EMAIL"); 
	  reqBody.put("contactValue", "aai3@gmail.com");
	
	  httpRequest =  oRAF.requestBody(httpRequest, reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("------------Code--------------- " +response.statusCode());
	  
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	 
 }
 
 /*****************************************************************/
 /*
  * Contact Mobile API
  * This bellow function helps to run the Contact Mobile API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 public void mobile()
 {
	 reqBody.put("contactType","PRIMARY_MOBILE"); 
	  reqBody.put("contactValue","6655678900"); 
	  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString()); 
	  System.out.println("-----------Code------------- " +response.statusCode());
	  
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	   
 }
 
 /*****************************************************************/
 /*
  * Final Check API
  * This bellow function helps to run the Final Check API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 public void finalCheck()
 {
	 
	  // EXECUTE
	  response = oRAF.execute(httpRequest, "get");
	  System.out.println(response.asString()); 
	  System.out.println("-----------------Code- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 200, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	 
	 
 }
 
 /*****************************************************************/
 /*
  * Final Request API
  * This bellow function helps to run the final request API.
  * @author  Muni Mathur
 */
 /*****************************************************************/ 
 
 public void finalRequest() throws InterruptedException
 {
	
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println(response.asString());
	  System.out.println("------------------Code- " +response.statusCode()); 
	 
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("--------------------Response Body is =>  " + responseBody);
	  
	  //Here we are capturing the Final Code for Signature Request
	  JsonPath jp = new JsonPath(response.asString());
	  FinalapplicationCode=jp.get("$.data[0].applicationCode");
		System.out.println(" ----------------Final Request applicationCode Code is ==> "+jp.get("FinalapplicationCode"));
	//  Thread.sleep(240000);
	 
 }
 
 public void signatureRequest()
 {
	 
	  reqBody.put(getcontractCOde,FinalapplicationCode); 
	  reqBody.put("cuid","85117"); 
	  reqBody.put("contractDocuments",""); 
	  
	  reqBody.put("$.[0].documentType","GTC"); 
	  reqBody.put("$.[0].signatureType","CONFIRMATION"); 
	  reqBody.put("$.[0].contentType","STATIC"); 
	  reqBody.put("$.[0].filename","general-terms-and-conditions"); 
	  
	  reqBody.put("$.[1].documentType","APPLICATION_FORM"); 
	  reqBody.put("$.[1].signatureType","CONFIRMATION"); 
	  reqBody.put("$.[1].contentType","GENERATED"); 
	  
	  reqBody.put("$.[2].documentType","SANCTIONAL_LETTER"); 
	  reqBody.put("$.[2].signatureType","CONFIRMATION"); 
	  reqBody.put("$.[2].contentType","GENERATED"); 
	  
	  reqBody.put("clientDocuments","null"); 
	  reqBody.put("verifications","null"); 
	  
	  System.out.println("--------------------"+httpRequest.toString());
	  
	  httpRequest = oRAF.requestBody(httpRequest,reqBody.toString());
	  	    	  
	  // EXECUTE 
	  response = oRAF.execute(httpRequest, "post");
	  System.out.println("Muni");
	  System.out.println(response.asString()); 
	
	  System.out.println("------------Code----- " +response.statusCode()); 
	  
	  Assert.assertEquals(response.statusCode(), 201, "Status code missmatch");
	  String responseBody = response.getBody().asString();
	  System.out.println("Response Body is =>  " + responseBody);
	 
 }
}
