package e2e_framework;

import java.io.File;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

/*****************************************************************/
/*
 * Base Class
 * The Purpose of this Class is to creating the folder where we are storing the result.
 * @author  Muni Mathur
*/
/*****************************************************************/

public abstract class Base 
{
	
	protected final String fileName = getClass().getSimpleName();
	protected final String htmlFilePath = getOutputFolder() + fileName + ".html";
	protected final String emailFilePath = getOutputFolder() + "email-" + fileName + ".html";
	protected ExtentReports extent;

	/*****************************************************************/
	/*
	 * The Purpose of this method is to set up the report .
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	@BeforeClass
	public void setup() 
	{
		
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(htmlFilePath);
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
	}

	/*****************************************************************/
	/*
	 * The Purpose of this method is to close the script & clear the report.
	 * @author  Muni Mathur
	*/
	/*****************************************************************/
	
	@AfterClass
	public void tearDown()
	{
		extent.flush();
	}

	
	protected String getOutputFolder()
	{
		return "test-Result/";
	}

	
	public Base() 
	{
		File folder = new File(getOutputFolder());
		folder.mkdirs();
		System.out.println("Result" + fileName);
	}
}
