package e2e_framework;


import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import utility.DataBaseConnection;

//Calling the Suite 

public abstract class ParallelClassesBase extends Base {
    //Methods defined in Base Class
    final String fileName = getOutputFolder() + getClass().getPackage().getName() + ".ParallelClasses.html";
    
    @BeforeSuite
    public void setup() {
    	//here we are update the status C 
    	DataBaseConnection.deleteContractID();
        ExtentManager.createInstance(fileName);
        ExtentTestManager.setReporter(ExtentManager.getInstance());
    }
    
    @AfterSuite
    public void tearDown()
    {
    	/*MailHelper mail=new MailHelper();
    	
			try {
				mail.sendMail();
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	*/	
         ExtentManager.getInstance().flush();
        //Delete contract ID
       // DataBaseConnection.deleteContractID();
    }
    
}
